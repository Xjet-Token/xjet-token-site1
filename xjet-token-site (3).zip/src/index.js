import React from "react";
import ReactDOM from "react-dom/client";
import XJETLandingPage from "./XJETLandingPage";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<XJETLandingPage />);